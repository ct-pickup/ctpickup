declare function zipState (zip: string): string | null;
export default zipState;
